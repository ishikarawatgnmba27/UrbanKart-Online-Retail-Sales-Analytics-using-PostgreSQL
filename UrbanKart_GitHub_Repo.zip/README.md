# UrbanKart: Online Retail Sales Analytics using PostgreSQL

End Sem Project, SQL and Data Management (PMDE30605), MBA, IILM University, Greater Noida.

**Group members:** [Member 1], [Member 2], [Member 3], [Member 4]

## What this project does
Designs and implements a normalised PostgreSQL database (customers, categories, products, orders, order_items) for a hypothetical e-commerce retailer, cleans messy data, and answers business questions using joins, aggregation, subqueries, CTEs, window functions and transactions.

## How to run (PostgreSQL 14+)
```bash
createdb urbankart_db
psql -d urbankart_db -f sql/01_schema.sql
psql -d urbankart_db -f sql/02_data.sql
psql -d urbankart_db -f sql/03_cleaning.sql
psql -d urbankart_db -f sql/04_analysis.sql
psql -d urbankart_db -f sql/05_integrity_transactions.sql
```

## Files
| File | Purpose |
|---|---|
| sql/01_schema.sql | Schema, tables, constraints, indexes |
| sql/02_data.sql | Hypothetical data (generated, seeded) |
| sql/03_cleaning.sql | Data cleaning and the `v_sales` view |
| sql/04_analysis.sql | 12 analytical queries |
| sql/05_integrity_transactions.sql | Constraint tests, COMMIT/ROLLBACK, function |
| outputs/ | Actual outputs from running the scripts |
| UrbanKart_SQL_Project_Report.pdf | Full project report |

Data is hypothetical and generated for academic purposes.
