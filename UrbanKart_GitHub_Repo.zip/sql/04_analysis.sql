SET search_path TO urbankart;
\echo '--- Q1 Monthly revenue and profit (completed orders)'
SELECT TO_CHAR(order_date,'YYYY-MM') AS month, COUNT(DISTINCT order_id) AS orders, SUM(revenue) AS revenue, SUM(profit) AS profit
FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY 1 ORDER BY 1;
\echo '--- Q2 Category performance'
SELECT category_name, SUM(quantity) AS units, SUM(revenue) AS revenue, SUM(profit) AS profit,
       ROUND(100*SUM(profit)/SUM(revenue),1) AS margin_pct
FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY 1 ORDER BY revenue DESC;
\echo '--- Q3 Top 5 customers by revenue with rank'
SELECT * FROM (SELECT full_name, city, segment, SUM(revenue) AS revenue,
       RANK() OVER (ORDER BY SUM(revenue) DESC) AS rnk
FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY full_name, city, segment) t WHERE rnk<=5;
\echo '--- Q4 Products earning above-average revenue (subquery)'
SELECT product_name, SUM(revenue) AS revenue FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY product_name
HAVING SUM(revenue) > (SELECT AVG(r) FROM (SELECT SUM(revenue) r FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY product_id) x)
ORDER BY revenue DESC;
\echo '--- Q5 Order status and cancellation/return rate'
SELECT status, COUNT(*) AS orders, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),1) AS pct FROM orders GROUP BY status ORDER BY orders DESC;
\echo '--- Q6 City-wise revenue'
SELECT city, COUNT(DISTINCT customer_id) AS customers, SUM(revenue) AS revenue
FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY city ORDER BY revenue DESC;
\echo '--- Q7 Payment mode share'
SELECT payment_mode, COUNT(*) AS orders, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),1) AS pct FROM orders GROUP BY 1 ORDER BY 2 DESC;
\echo '--- Q8 Customers with no orders (LEFT JOIN)'
SELECT c.customer_id, c.full_name FROM customers c LEFT JOIN orders o USING(customer_id) WHERE o.order_id IS NULL;
\echo '--- Q9 Running total and month-over-month growth (CTE + window)'
WITH m AS (SELECT TO_CHAR(order_date,'YYYY-MM') mon, SUM(revenue) rev FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY 1)
SELECT mon, rev, SUM(rev) OVER (ORDER BY mon) AS running_total,
       ROUND(100*(rev-LAG(rev) OVER (ORDER BY mon))/LAG(rev) OVER (ORDER BY mon),1) AS mom_growth_pct FROM m ORDER BY mon;
\echo '--- Q10 Best-selling product in each category (CTE + ROW_NUMBER)'
WITH p AS (SELECT category_name, product_name, SUM(revenue) rev, ROW_NUMBER() OVER (PARTITION BY category_name ORDER BY SUM(revenue) DESC) rn
FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY category_name, product_name)
SELECT category_name, product_name, rev FROM p WHERE rn=1 ORDER BY rev DESC;
\echo '--- Q11 Customer value segmentation (CASE)'
WITH t AS (SELECT customer_id, full_name, SUM(revenue) spend FROM v_sales WHERE status IN ('Delivered','Shipped') GROUP BY 1,2)
SELECT CASE WHEN spend>=40000 THEN 'High value' WHEN spend>=20000 THEN 'Mid value' ELSE 'Low value' END AS tier,
       COUNT(*) customers, ROUND(AVG(spend)) avg_spend FROM t GROUP BY 1 ORDER BY 3 DESC;
\echo '--- Q12 Low stock products vs units sold'
SELECT p.product_name, p.stock_qty, COALESCE(SUM(oi.quantity),0) AS units_sold
FROM products p LEFT JOIN order_items oi USING(product_id) GROUP BY p.product_id ORDER BY p.stock_qty - COALESCE(SUM(oi.quantity),0) LIMIT 5;
