SET search_path TO urbankart;
-- 1. Standardise text
UPDATE customers SET city = INITCAP(TRIM(city)), full_name = INITCAP(TRIM(full_name));
-- 2. Handle missing values
UPDATE customers SET email = 'unknown_'||customer_id||'@noemail.com' WHERE email IS NULL;
UPDATE orders SET payment_mode = 'Unknown' WHERE payment_mode IS NULL;
-- 3. Remove duplicate/invalid customer record (no orders, malformed email)
DELETE FROM customers WHERE email NOT LIKE '%@%.com' AND customer_id NOT IN (SELECT customer_id FROM orders);
-- 4. Transformation view: order-line revenue and profit
CREATE OR REPLACE VIEW v_sales AS
SELECT o.order_id, o.order_date, o.status, o.payment_mode, c.customer_id, c.full_name, c.city, c.segment,
       p.product_id, p.product_name, cat.category_name, oi.quantity, oi.discount_pct,
       ROUND(oi.quantity*p.unit_price*(1-oi.discount_pct/100),2) AS revenue,
       ROUND(oi.quantity*p.unit_price*(1-oi.discount_pct/100) - oi.quantity*p.cost_price,2) AS profit
FROM order_items oi
JOIN orders o ON o.order_id=oi.order_id
JOIN customers c ON c.customer_id=o.customer_id
JOIN products p ON p.product_id=oi.product_id
JOIN categories cat ON cat.category_id=p.category_id;
