SET search_path TO urbankart;
\echo '--- T1 Constraint test: negative price must fail'
INSERT INTO products(product_name,category_id,unit_price,cost_price) VALUES ('Bad Item',1,-10,5);
\echo '--- T2 FK test: order for non-existent customer must fail'
INSERT INTO orders(customer_id,order_date,status) VALUES (9999,CURRENT_DATE,'Shipped');
\echo '--- T3 Successful transaction: place order and reduce stock'
BEGIN;
INSERT INTO orders(customer_id,order_date,status,payment_mode) VALUES (1,DATE '2026-03-01','Shipped','UPI') RETURNING order_id \gset
INSERT INTO order_items(order_id,product_id,quantity,discount_pct) VALUES (:order_id,1,2,10);
UPDATE products SET stock_qty = stock_qty - 2 WHERE product_id=1;
COMMIT;
SELECT product_id, stock_qty FROM products WHERE product_id=1;
\echo '--- T4 Rolled-back transaction'
BEGIN;
UPDATE products SET stock_qty = stock_qty - 5 WHERE product_id=2;
SELECT product_id, stock_qty AS stock_inside_txn FROM products WHERE product_id=2;
ROLLBACK;
SELECT product_id, stock_qty AS stock_after_rollback FROM products WHERE product_id=2;
\echo '--- T5 Stored function: customer lifetime value'
CREATE OR REPLACE FUNCTION customer_ltv(cid INT) RETURNS NUMERIC AS $$
  SELECT COALESCE(SUM(revenue),0) FROM v_sales WHERE customer_id=cid AND status IN ('Delivered','Shipped');
$$ LANGUAGE sql;
SELECT customer_ltv(1) AS ltv_customer_1;
