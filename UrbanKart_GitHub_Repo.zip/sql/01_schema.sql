-- UrbanKart Online Retail Database (PostgreSQL)
DROP SCHEMA IF EXISTS urbankart CASCADE;
CREATE SCHEMA urbankart;
SET search_path TO urbankart;

CREATE TABLE customers (
  customer_id SERIAL PRIMARY KEY,
  full_name   VARCHAR(80) NOT NULL,
  email       VARCHAR(100) UNIQUE,
  city        VARCHAR(40),
  segment     VARCHAR(20) CHECK (segment IN ('Regular','Premium','Corporate')),
  joined_on   DATE NOT NULL
);
CREATE TABLE categories (
  category_id SERIAL PRIMARY KEY,
  category_name VARCHAR(40) NOT NULL UNIQUE
);
CREATE TABLE products (
  product_id  SERIAL PRIMARY KEY,
  product_name VARCHAR(80) NOT NULL,
  category_id INT NOT NULL REFERENCES categories(category_id),
  unit_price  NUMERIC(10,2) NOT NULL CHECK (unit_price > 0),
  cost_price  NUMERIC(10,2) NOT NULL CHECK (cost_price > 0),
  stock_qty   INT NOT NULL DEFAULT 0 CHECK (stock_qty >= 0)
);
CREATE TABLE orders (
  order_id    SERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES customers(customer_id),
  order_date  DATE NOT NULL,
  status      VARCHAR(15) NOT NULL CHECK (status IN ('Delivered','Shipped','Cancelled','Returned')),
  payment_mode VARCHAR(15)
);
CREATE TABLE order_items (
  item_id    SERIAL PRIMARY KEY,
  order_id   INT NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
  product_id INT NOT NULL REFERENCES products(product_id),
  quantity   INT NOT NULL CHECK (quantity > 0),
  discount_pct NUMERIC(4,1) NOT NULL DEFAULT 0 CHECK (discount_pct BETWEEN 0 AND 50)
);
CREATE INDEX idx_orders_cust ON orders(customer_id);
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_items_order ON order_items(order_id);
CREATE INDEX idx_items_prod  ON order_items(product_id);
