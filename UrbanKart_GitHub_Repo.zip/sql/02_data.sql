SET search_path TO urbankart;
INSERT INTO categories(category_name) VALUES
('Electronics'),('Fashion'),('Home & Kitchen'),('Books'),('Sports');

INSERT INTO products(product_name,category_id,unit_price,cost_price,stock_qty) VALUES
('Wireless Earbuds',1,2499,1500,120),('Smart Watch',1,5999,3900,60),('Bluetooth Speaker',1,1999,1200,90),
('Power Bank 20000mAh',1,1799,1000,150),('Men Running Shoes',2,2999,1700,80),('Women Kurta Set',2,1499,800,200),
('Denim Jacket',2,2299,1300,70),('Air Fryer 4L',3,4499,2900,45),('Non-stick Cookware Set',3,2799,1700,65),
('Mixer Grinder',3,3299,2100,50),('SQL Made Easy',4,499,250,300),('Data Science Handbook',4,799,420,250),
('Yoga Mat',5,899,420,180),('Dumbbell Set 10kg',5,1999,1150,75),('Cricket Bat',5,2499,1500,40);

-- 60 customers generated deterministically; some deliberately messy for the cleaning step
INSERT INTO customers(full_name,email,city,segment,joined_on)
SELECT 'Customer '||g,
       'cust'||g||'@mail.com',
       (ARRAY['Delhi','Mumbai','Bengaluru','Pune','Ghaziabad','Noida','Hyderabad','Chennai'])[1+(g%8)],
       (ARRAY['Regular','Regular','Premium','Corporate'])[1+(g%4)],
       DATE '2024-01-01' + (g*9)
FROM generate_series(1,60) g;

-- dirty rows (to be cleaned in script 03)
UPDATE customers SET city='  delhi ' WHERE customer_id IN (3,11);
UPDATE customers SET city='MUMBAI' WHERE customer_id IN (6,14);
UPDATE customers SET city='bengaluru' WHERE customer_id IN (9);
UPDATE customers SET full_name='  customer 20  ' WHERE customer_id=20;
UPDATE customers SET email=NULL WHERE customer_id IN (25,41);
INSERT INTO customers(full_name,email,city,segment,joined_on)
VALUES ('Customer 7 Duplicate','cust7@mail.com_dup','Pune','Regular','2025-02-01');

-- 400 orders, deterministic pseudo-random
SELECT setseed(0.42);
INSERT INTO orders(customer_id,order_date,status,payment_mode)
SELECT 1+floor(random()*60)::int,
       DATE '2025-01-01' + floor(random()*320)::int,
       (ARRAY['Delivered','Delivered','Delivered','Delivered','Delivered','Shipped','Cancelled','Returned'])[1+floor(random()*8)::int],
       (ARRAY['UPI','Card','COD','NetBanking','UPI','Card'])[1+floor(random()*6)::int]
FROM generate_series(1,400);
UPDATE orders SET payment_mode=NULL WHERE order_id IN (5,17,88);

-- 1-4 items per order
INSERT INTO order_items(order_id,product_id,quantity,discount_pct)
SELECT o.order_id,
       1+floor(random()*15)::int,
       1+floor(random()*3)::int,
       (ARRAY[0,0,5,10,15,20])[1+floor(random()*6)::int]
FROM orders o, generate_series(1,2) k
UNION ALL
SELECT o.order_id, 1+floor(random()*15)::int, 1+floor(random()*2)::int, 0
FROM orders o WHERE o.order_id % 2 = 0;
